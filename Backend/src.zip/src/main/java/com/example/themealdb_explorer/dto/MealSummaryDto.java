package com.example.themealdb_explorer.dto;

import lombok.Data;

@Data
public class MealSummaryDto {
    private String id;
    private String name;
    private String thumbnail;
}
