package com.example.themealdb_explorer.dto;

import lombok.Data;

@Data
public class CategoryDto {
    private String name;
}
